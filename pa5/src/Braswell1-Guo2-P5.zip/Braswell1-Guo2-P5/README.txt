process: Eliminated possible options in the Heuristics until we found a sufficent goal. Examples of this process was checking the max required cobble for crafting.We also compared the current state with the goal state. In the final list of tuples, the first value is the state before the action is carried out.

names: Tre Braswell and Yutong Guo
Notes: we assumed that we didnt include the goal action in the final path.